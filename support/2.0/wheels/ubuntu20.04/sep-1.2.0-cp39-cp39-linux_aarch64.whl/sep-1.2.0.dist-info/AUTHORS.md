* Emmanuel Bertin (bertin@iap.fr) : original SExtractor code
* Kyle Barbary (@kbarbary) : Conversion of SExtractor code to library
* Kyle Boone (@kboone) : Bugfix, matched filter
* Thomas Robitaille (@astrofrog) : Exact aperture overlap code
* Matt Craig (@mwcraig) : Windows & OS X support
* Curtis McCully (@cmccully): Parameter uncertainties
* Evert Rol (@evertrol): setup.py fixes
* Joe Lyman (@lyalpha): Make deblending limit settable
* Michael Wuertenberger (@mworion): PyPI wheels
* Ingvar Stepanyan (@rreverser): Build system, public API and thread safety fixes.
