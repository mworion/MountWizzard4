This folder contains data files bundled with `photutils`.

fermi_counts.fits.gz
--------------------

Fermi LAT counts image created by Christoph Deil (copied from Gammapy).
