./venv/Scripts/activate
./venv/Scripts/python venv/Lib/site-packages/mw4/loader.py
./deactivate