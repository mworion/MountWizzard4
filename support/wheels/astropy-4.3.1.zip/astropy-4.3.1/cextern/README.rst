External Packages/Libraries
===========================

This directory contains C libraries included with Astropy. Note that only C
libraries without python-specific code  should be included in this directory.
Cython or C code intended for use with Astropy or wrapper code should be in
the Astropy source tree.

