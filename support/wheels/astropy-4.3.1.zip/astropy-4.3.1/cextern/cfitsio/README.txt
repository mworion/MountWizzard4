Note: astropy only requires the CFITSIO library, and hence in this bundled version,
we removed all other files except the required license (License.txt) and changelog
(docs/changes.txt, which has the version number).
