Note: astropy only requires the expat library, and hence in this bundled version,
we removed all other files except the required license and changelog.
