.. _astropy_config_file:

Astropy's Default Configuration File
************************************

 .. generate_config:: astropy
