:orphan:

***********************
Astropy Docstring Rules
***********************

The rules for Astropy docstrings are now the same as those given in the
[numpydoc documentation](https://numpydoc.readthedocs.io/en/latest/format.html).
