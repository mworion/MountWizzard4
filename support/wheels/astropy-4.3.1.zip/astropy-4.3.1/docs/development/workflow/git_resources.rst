:orphan:

.. _git-resources:

*************
Git resources
*************

Tutorials and summaries
***********************

* `GitHub Help`_ has an excellent series of how-to guides.
* `learn.github`_ has an excellent series of tutorials
* The `pro git book`_ is a good in-depth book on git.
* A `git cheat sheet`_ is a page giving summaries of common commands.
* The `git user manual`_
* The `git tutorial`_
* The `git community book`_
* `git ready`_ |emdash| a nice series of tutorials
* `git casts`_ |emdash| video snippets giving git how-tos.
* `git magic`_ |emdash| extended introduction with intermediate detail
* The `git parable`_ is an easy read explaining the concepts behind git.
* `git foundation`_ expands on the `git parable`_.
* Fernando Perez' git page |emdash| `Fernando's git page`_ |emdash| many
  links and tips
* Fernando Perez's `ipython notebook on using git in science`_
* A good but technical page on `git concepts`_
* `git svn crash course`_: git for those of us used to subversion

Manual pages online
*******************

You can get these on your own machine with (e.g) ``git help push`` or
(same thing) ``git push --help``, but, for convenience, here are the
online manual pages for some common commands:

* `git add`_
* `git branch`_
* `git checkout`_
* `git clone`_
* `git commit`_
* `git config`_
* `git diff`_
* `git log`_
* `git pull`_
* `git push`_
* `git remote`_
* `git status`_

.. include:: links.inc
