:orphan:

****************************
Getting Started with Astropy
****************************

This page has been moved to :ref:`getting-started`. Please update your links.
