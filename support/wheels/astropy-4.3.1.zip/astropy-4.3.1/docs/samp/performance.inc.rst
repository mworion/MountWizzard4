.. note that if this is changed from the default approach of using an *include*
   (in index.rst) to a separate performance page, the header needs to be changed
   from === to ***, the filename extension needs to be changed from .inc.rst to
   .rst, and a link needs to be added in the subpackage toctree

.. _astropy-samp-performance:

.. Performance Tips
.. ================
..
.. Here we provide some tips and tricks for how to optimize performance of code
.. using `astropy.samp`.
