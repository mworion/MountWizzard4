Loading WCS Information from a FITS File
----------------------------------------

This example loads a FITS file (supplied on the command line) and uses
the FITS keywords in its primary header to create a WCS and transform.

.. literalinclude:: examples/from_file.py
   :language: python
