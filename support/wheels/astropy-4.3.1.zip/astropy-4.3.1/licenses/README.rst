Licenses
========

This directory holds license and credit information for works astropy is derived from or distributes, and/or datasets.

The license file for the astropy package itself is placed in the root directory of this repository.
