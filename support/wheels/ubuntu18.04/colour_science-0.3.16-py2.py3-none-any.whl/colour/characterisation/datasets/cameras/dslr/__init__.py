# -*- coding: utf-8 -*-

from __future__ import absolute_import

from .sensitivities import MSDS_CAMERA_SENSITIVITIES_DSLR

__all__ = ['MSDS_CAMERA_SENSITIVITIES_DSLR']
