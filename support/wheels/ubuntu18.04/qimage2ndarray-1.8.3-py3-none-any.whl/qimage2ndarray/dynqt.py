from .qt_driver import QtDriver

qt = QtDriver()
QtGui = qt.QtGui
