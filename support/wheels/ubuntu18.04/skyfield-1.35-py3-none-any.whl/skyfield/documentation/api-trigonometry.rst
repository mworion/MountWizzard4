
==============================
 API Reference — Trigonometry
==============================

.. currentmodule:: skyfield.trigonometry

.. autofunction:: position_angle_of
